
1. Extract the extension in files

2. Go to: chrome://extensions/ (this only works on chrome ^^)

3. Enable Developer mode (top right of the screen, you will see a turn on for it)

4. click load unpacked (top left in extensions tab, should open file explorer)

5. select the folder you just extracted

6. Go to: https://throne.com/astolfodia

7. Hands off your mouse and keyboard and let it run~ <3



