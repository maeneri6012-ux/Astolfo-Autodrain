const tabsAPI = typeof chrome !== 'undefined' && chrome.tabs ? chrome.tabs : browser.tabs;

function openThroneTab() {
  tabsAPI.create({ url: "https://throne.com/astolfodia" });
  scheduleNextOpen();
}

function getRandomInterval() {
  const minHours = 2;
  const maxHours = 3;
  const hours = Math.random() * (maxHours - minHours) + minHours;
  return hours * 60 * 60 * 1000; 
}

function scheduleNextOpen() {
  const interval = getRandomInterval();
  console.log(`Next tab will open in approximately ${Math.round(interval / (60 * 60 * 1000))} hours`);
  setTimeout(openThroneTab, interval);
}

scheduleNextOpen();

// Made by @petgirlnova on Twitter!!~ If you need help remaking this to fit your needs, DM me! <3 (slight tip needed btw~)