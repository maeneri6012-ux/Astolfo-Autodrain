var audioOpened = false;
var payClicked = false;

function clickAddToCartForschrlp() {
  setTimeout(() => {
    const productCards = document.querySelectorAll("[class*=chakra-stack]");
    for (const card of productCards) {
      const label = card.querySelector("p");
      if (label && label.textContent.trim().toLowerCase().includes("coffee")) { 
        const addButton = card.querySelector("button");
        if (addButton && addButton.textContent.toLowerCase().includes("add to cart")) {
          console.log("Clicking 'Add to cart' for coffee");
          addButton.click();
          return;
        }
      }
    }
  }, 6000);
}

function clickCheckoutIfExists() {
  setTimeout(() => {
    const buttons = document.querySelectorAll("button");
    for (const btn of buttons) {
      if (btn.textContent.trim().toLowerCase() === "checkout") {
        console.log("Clicking Checkout...");
        btn.click();
        return;
      }
    }
  }, 6000);
}

function clickPayNowIfExists() {
  setTimeout(() => {
    const buttons = document.querySelectorAll("button");
    for (const btn of buttons) {
      const span = btn.querySelector("span");
      if (span && span.textContent.trim().toLowerCase() === "pay now" && !btn.disabled) {
        console.log("Clicking Pay Now...");
        btn.click();
        payClicked = true;
        return;
      }
    }
  }, 7000);
}

function spawnImage() {
  const imagePaths = [ 
    "images/1.jpg",
    "images/2.jpg",
    "images/3.png",
    "images/4.png",
    "images/5.png",
    "images/6.png",
    "images/7.png",
    "images/8.png",
    "images/9.png",
    "images/10.png",
    "images/11.png",
    "images/12.png",
    "images/13.png",
    "images/14.png",
    "images/15.png",
    "images/16.png",
    "images/17.png",
    "images/18.png",
    "images/19.png",
    "images/20.png",
    "images/21.png",
    "images/22.png",
    "images/23.png",
    "images/24.png",
    "images/25.png",
    "images/26.png",
    "images/27.png",
    "images/28.png",
    "images/29.png",
    "images/30.png",
    "images/31.png",
    "images/32.png",
    "images/33.png",
    "images/34.png",
    "images/35.png",
    "images/36.png",
    "images/37.png",
    "images/38.png",
    "images/39.png",
    "images/40.png",
    "images/41.png",
    "images/42.png",
    "images/43.png",
    "images/44.png",
    "images/45.png",
    "images/46.png",
    "images/47.png",
 


  ];

  const randomIndex = Math.floor(Math.random() * imagePaths.length);
  const randomPath = imagePaths[randomIndex];

  if (!randomPath || typeof chrome?.runtime?.getURL !== 'function') {
    console.warn("Could not generate image URL.");
    return;
  }

  const fullPath = chrome.runtime.getURL(randomPath);

  const imgLoader = new Image();
  imgLoader.src = fullPath;

  imgLoader.onload = function () {
    const scale = 0.5; // adjust as needed
    const img = document.createElement('img');
    img.src = fullPath;
    img.style.position = 'fixed';
    img.style.left = Math.random() * (window.innerWidth - imgLoader.naturalWidth * scale) + 'px';
    img.style.top = Math.random() * (window.innerHeight - imgLoader.naturalHeight * scale) + 'px';
    img.style.width = (imgLoader.naturalWidth * scale) + 'px';
    img.style.height = (imgLoader.naturalHeight * scale) + 'px';
    img.style.zIndex = '10000';
    img.style.pointerEvents = 'none';
    document.body.appendChild(img);

    setTimeout(() => img.remove(), 10000);
  };

  imgLoader.onerror = function () {
    console.error("Failed to load image:", fullPath);
  };
}

function mainLoop() {
  const url = window.location.href;

  if (url.includes("https://throne.com/astolfodia/checkout")) {
    clickPayNowIfExists();
  }
    if (url.includes("https://throne.com/astolfodia")) {
    clickAddToCartForschrlp();
    clickCheckoutIfExists();
  }

  setTimeout(mainLoop, 3000);
}

// Start everything
mainLoop();
setInterval(spawnImage, 1000);





